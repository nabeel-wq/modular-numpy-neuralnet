# Modular Neural Network

This is a simple implementation of a feedforward neural network using backpropagation and stochastic gradient descent.
